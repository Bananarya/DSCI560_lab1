name=input("please provide you name\n")
print(f"Hello, {name}!")
